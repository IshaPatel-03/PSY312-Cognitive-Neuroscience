
%% FIGURE A - COMPLETE SCRIPT WITH DENSITY WAVES
% Replication of Lee et al. (2024), Figure 2
% No Statistics and Machine Learning Toolbox required
%
% NOTE: This is a PROVISIONAL figure until participant-ID
% matching and two unusual questionnaire scores are verified.

clear;
clc;
close all;

%% 1. SELECT EXPERIMENT DATA FOLDER

folder = uigetdir(pwd, ...
    'Select the folder containing participant CSV files');

if isequal(folder,0)
    error('No experiment folder selected.');
end

files = dir(fullfile(folder,'*.csv'));

allData = table();
fileCount = 0;

for i = 1:numel(files)

    filename = files(i).name;

    % Skip analysis output files
    if startsWith(filename,'Figure_') || ...
       startsWith(filename,'GoldMSI_') || ...
       startsWith(filename,'Provisional_')
        continue;
    end

    T = readtable(fullfile(folder,filename), ...
        'VariableNamingRule','preserve');

    if width(T) ~= 6
        continue;
    end

    T.Properties.VariableNames = ...
        {'subject','starttime','videoname', ...
         'category_num','response','RT'};

    allData = [allData; T];
    fileCount = fileCount + 1;

end

fprintf('Loaded %d participant files.\n',fileCount);
fprintf('Total trials: %d\n',height(allData));

%% 2. CALCULATE MCGURK FUSION PERCENTAGE

isMG = allData.category_num >= 1 & ...
       allData.category_num <= 8;

MG = allData(isMG,:);

MG.fusion = double(MG.response == 3);

subjects = sort(unique(MG.subject));
nSubjects = numel(subjects);

fusion = NaN(nSubjects,1);

for i = 1:nSubjects

    idx = MG.subject == subjects(i);

    fusion(i) = 100 * mean(MG.fusion(idx));

end

fprintf('Participants: %d\n',nSubjects);
fprintf('Mean fusion: %.2f%%\n',mean(fusion));

%% 3. SELECT GOLD-MSI EXCEL FILE

%% 3. LOAD GOLD-MSI EXCEL FILE

% Look for the Excel file in the same folder as this script
scriptFolder = fileparts(mfilename('fullpath'));

goldFile = fullfile(scriptFolder,'GOLD_MSI_OSF.xlsx');

% If not there, look in the selected participant folder
if ~isfile(goldFile)
    goldFile = fullfile(folder,'GOLD_MSI_OSF.xlsx');
end

% Stop with a clear message if the file is still missing
if ~isfile(goldFile)
    error(['GOLD_MSI_OSF.xlsx was not found. ' ...
           'Please copy it into the same folder as FigureAWithWaves.m']);
end

fprintf('Gold-MSI file found: %s\n',goldFile);

opts = detectImportOptions(goldFile, ...
    'VariableNamingRule','preserve');

opts.VariableNamesRange = 'A2';
opts.DataRange = 'A5';

gold = readtable(goldFile,opts);

questionNames = cellstr("Q" + string(1:38));

S = double(gold{:,questionNames});

if size(S,1) ~= nSubjects
    error('Experiment and questionnaire counts do not match.');
end

%% 4. REVERSE-SCORE NEGATIVELY WORDED QUESTIONS

reverseItems = [9 11 13 14 17 21 23 25 27];

S(:,reverseItems) = 8 - S(:,reverseItems);

%% 5. FLAG TWO OUT-OF-RANGE EXPERIENCE ANSWERS
% Original Excel values remain unchanged.

S(S(:,32)<1 | S(:,32)>7,32) = NaN;
S(S(:,36)<1 | S(:,36)>7,36) = NaN;

%% 6. DEFINE GOLD-MSI SCALES

items = {
    [1 3 8 15 21 24 28 34 38]
    [5 6 11 12 13 18 22 23 26]
    [14 27 32 33 35 36 37]
    [4 7 10 17 25 29 30]
    [2 9 16 19 20 31]
    [1 3 4 7 10 12 14 15 17 19 23 24 25 27 29 32 33 37]
};

scaleNames = {
    'Active Engagement'
    'Perceptual Abilities'
    'Musical Training'
    'Singing Abilities'
    'Emotions'
    'General Musical Sophistication'
};

paperMeans = [40 45 25 28 32 75];

%% 7. CALCULATE GOLD-MSI SCORES

scores = NaN(height(gold),6);

fprintf('\nGOLD-MSI RESULTS\n');
fprintf('-------------------------------------------\n');

for k = 1:6

    scores(:,k) = sum(S(:,items{k}),2);

    valid = isfinite(scores(:,k));

    fprintf('%s: %.2f (paper: ~%d, n=%d)\n', ...
        scaleNames{k}, ...
        mean(scores(valid,k)), ...
        paperMeans(k), ...
        sum(valid));

end

%% 8. SAVE SCORES AND PROVISIONAL ID MAPPING

scoreTable = table(string(gold.Q44), ...
    'VariableNames',{'GoldMSI_ID'});

scoreTable.Active = scores(:,1);
scoreTable.Perceptual = scores(:,2);
scoreTable.Training = scores(:,3);
scoreTable.Singing = scores(:,4);
scoreTable.Emotions = scores(:,5);
scoreTable.General = scores(:,6);

writetable(scoreTable,'GoldMSI_Scores.csv');

mapping = table(subjects,string(gold.Q44), ...
    'VariableNames',{'ExperimentSubject','GoldMSI_ID'});

mapping.MatchStatus = repmat( ...
    "Provisional - verify",nSubjects,1);

writetable(mapping,'Provisional_ID_Mapping.csv');

%% 9. CREATE FIGURE WITH DENSITY WAVES

fig = figure( ...
    'Color','w', ...
    'Position',[100 70 1450 950], ...
    'Visible','on');

for k = 1:6

    rowIndex = floor((k-1)/3);
    colIndex = mod(k-1,3);

    left = 0.065 + colIndex*0.315;
    bottom = 0.575 - rowIndex*0.465;

    plotW = 0.225;
    plotH = 0.295;

    % Blue panels A-E; orange panel F
    if k < 6
        clr = [0.17 0.76 0.96];
    else
        clr = [0.96 0.57 0.35];
    end

    x = scores(:,k);
    y = fusion;

    valid = isfinite(x) & isfinite(y);

    x = x(valid);
    y = y(valid);

    xPad = max(2,0.06*(max(x)-min(x)));
    xLimits = [min(x)-xPad max(x)+xPad];

    %% MAIN SCATTERPLOT

    ax = axes('Parent',fig, ...
        'Position',[left bottom plotW plotH], ...
        'Color','w', ...
        'XColor','k', ...
        'YColor','k');

    hold(ax,'on');

    scatter(ax,x,y,42,clr,'filled', ...
        'MarkerEdgeColor','w', ...
        'LineWidth',0.5);

    % Black regression line
    p = polyfit(x,y,1);

    xx = linspace(min(x),max(x),200);

    plot(ax,xx,polyval(p,xx), ...
        'Color',[0.20 0.20 0.20], ...
        'LineWidth',1.5);

    xlim(ax,xLimits);
    ylim(ax,[0 105]);

    xlabel(ax,scaleNames{k}, ...
        'FontSize',11,'Color','k');

    if colIndex == 0
        ylabel(ax,'McGurk fusion (%)', ...
            'FontSize',11,'Color','k');
    end

    set(ax, ...
        'FontSize',10, ...
        'LineWidth',1.1, ...
        'Box','on', ...
        'TickDir','out', ...
        'XColor','k', ...
        'YColor','k', ...
        'Color','w');

    grid(ax,'off');

    %% PANEL LETTER

    letter = char('A'+k-1);

    text(ax,-0.13,1.19,['(' letter ')'], ...
        'Units','normalized', ...
        'FontSize',14, ...
        'FontWeight','bold', ...
        'Color','k');

    %% TOP DENSITY WAVE

    axTop = axes('Parent',fig, ...
        'Position', ...
        [left bottom+plotH+0.008 plotW 0.065], ...
        'Color','none');

    gridX = linspace(xLimits(1),xLimits(2),250);

    densX = localDensity(x,gridX);

    fill(axTop, ...
        [gridX fliplr(gridX)], ...
        [densX zeros(size(densX))], ...
        clr, ...
        'FaceAlpha',0.28, ...
        'EdgeColor',clr, ...
        'LineWidth',1.2);

    xlim(axTop,xLimits);

    set(axTop, ...
        'Visible','off', ...
        'Color','none');

    %% RIGHT DENSITY WAVE
    if mod(k,2) == 0

    axRight = axes('Parent',fig, ...
        'Position', ...
        [left+plotW+0.007 bottom 0.046 plotH], ...
        'Color','none');

    gridY = linspace(0,105,250);

    densY = localDensity(y,gridY);

    fill(axRight, ...
        [zeros(size(densY)) fliplr(densY)], ...
        [gridY fliplr(gridY)], ...
        clr, ...
        'FaceAlpha',0.28, ...
        'EdgeColor',clr, ...
        'LineWidth',1.2);

    ylim(axRight,[0 105]);

    set(axRight, ...
        'Visible','off', ...
        'Color','none');
    end

end

%% 10. ADD FIGURE TITLE

sgtitle(fig, ...
    'Figure A - Provisional Gold-MSI and McGurk Fusion', ...
    'FontSize',16, ...
    'FontWeight','bold', ...
    'Color','k');

%% 11. SAVE FIGURE

exportgraphics(fig, ...
    'Figure_A_With_Densities.png', ...
    'Resolution',300, ...
    'BackgroundColor','white');

savefig(fig,'Figure_A_With_Densities.fig');

% Keep figure open
figure(fig);
shg;

fprintf('\nFILES SAVED:\n');
fprintf('Figure_A_With_Densities.png\n');
fprintf('Figure_A_With_Densities.fig\n');
fprintf('GoldMSI_Scores.csv\n');
fprintf('Provisional_ID_Mapping.csv\n');

%% 12. TOOLBOX-FREE KERNEL DENSITY FUNCTION
% This function MUST stay at the end of the script.

function f = localDensity(data,grid)

    data = data(isfinite(data));

    n = numel(data);

    if n == 0
        f = zeros(size(grid));
        return;
    end

    sigma = std(data);

    h = 1.06*sigma*n^(-1/5);

    if ~isfinite(h) || h <= 0
        h = 1;
    end

    f = zeros(size(grid));

    for j = 1:n

        z = (grid-data(j))/h;

        f = f + exp(-0.5*z.^2);

    end

    f = f/(n*h*sqrt(2*pi));

end


%% PARTICIPANT MATCHING AUDIT
% Checks experiment IDs, questionnaire IDs and dates.
% Does not change the figure or scores.

expIDs = sort(unique(allData.subject));
goldIDs = string(gold.Q44);

fprintf('\n=== PARTICIPANT MATCHING AUDIT ===\n');
fprintf('Experiment participants: %d\n',numel(expIDs));
fprintf('Gold-MSI questionnaires: %d\n',numel(goldIDs));
fprintf('Unique questionnaire IDs: %d\n',numel(unique(goldIDs)));

% Show questionnaire IDs alongside assumed experiment IDs
audit = table(expIDs,goldIDs, ...
    'VariableNames',{'ExperimentSubject','GoldMSI_ID'});

disp('FIRST 25 PAIRS:');
disp(audit(1:min(25,height(audit)),:));

disp('LAST 15 PAIRS:');
disp(audit(max(1,height(audit)-14):end,:));

% Inspect available experiment timestamps
disp('EXPERIMENT TIMESTAMP EXAMPLES:');
disp(allData(1:min(5,height(allData)), ...
    {'subject','starttime'}));

% Inspect questionnaire date fields
dateVars = intersect( ...
    {'StartDate','EndDate','RecordedDate'}, ...
    gold.Properties.VariableNames,'stable');

if ~isempty(dateVars)
    disp('QUESTIONNAIRE DATE EXAMPLES:');
    disp(gold(1:min(5,height(gold)),dateVars));
end

writetable(audit,'Participant_Matching_Audit.csv');

fprintf('Saved Participant_Matching_Audit.csv\n');

%% CHECK SECOND-GROUP QUESTIONNAIRE ORDER

dates = datetime(string(gold.RecordedDate), ...
    'InputFormat','M/d/yy H:mm');

secondGroup = 24:height(gold);

dateAudit = table( ...
    subjects(secondGroup), ...
    string(gold.Q44(secondGroup)), ...
    dates(secondGroup), ...
    'VariableNames', ...
    {'AssumedSubject','QuestionnaireID','RecordedDate'});

disp('FIRST 10 SECOND-GROUP RECORDS:');
disp(dateAudit(1:10,:));

disp('LAST 10 SECOND-GROUP RECORDS:');
disp(dateAudit(end-9:end,:));

fprintf('Second-group dates chronological: %d\n', ...
    all(diff(dates(secondGroup)) >= 0));

fprintf('Date range: %s to %s\n', ...
    datestr(min(dates(secondGroup))), ...
    datestr(max(dates(secondGroup))));