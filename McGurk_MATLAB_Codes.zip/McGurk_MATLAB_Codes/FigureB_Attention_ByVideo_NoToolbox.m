%% FIGURE B - McGurk fusion by audiovisual stimulus (your attention experiment)
% Base MATLAB only. Reads 20 ORIGINAL PsychoPy participant CSVs.
% Stimuli 2.1 through 2.8; DA or THA counts as fusion.
% Each bar = mean of participant-specific fusion percentages for that video,
% pooled across focused/search10/search15; blank responses excluded.
clear; clc; close all;
rawFolder = uigetdir(pwd,'Select folder with the 20 ORIGINAL participant CSVs');
if isequal(rawFolder,0), error('No folder selected.'); end
files = dir(fullfile(rawFolder,'*_McGurk_Attention*.csv'));
if numel(files) ~= 20
    error('Expected 20 participant CSVs; found %d.',numel(files));
end
nP = numel(files); videoIDs = "2." + string(1:8);
participantRates = NaN(nP,8); validCounts = zeros(nP,8);
allValid = zeros(nP,1); allFusion = zeros(nP,1);
for p = 1:nP
    fp = fullfile(files(p).folder,files(p).name);
    opts = detectImportOptions(fp,'VariableNamingRule','preserve');
    needed = {'attention','stimType','stimID','textbox.text'};
    for j = 1:numel(needed)
        if ~ismember(needed{j},opts.VariableNames)
            error('Missing column %s in %s',needed{j},files(p).name);
        end
        opts = setvartype(opts,needed{j},'string');
    end
    T = readtable(fp,opts);
    attention = lower(strtrim(string(T.attention)));
    isMG = strcmpi(strtrim(string(T.stimType)),'McGurk') & ...
        ismember(attention,["focused","search10","search15"]);
    ids = strtrim(string(T.stimID));
    resp = upper(regexprep(strtrim(string(T.('textbox.text'))),'\s+',''));
    valid = ismember(resp,["BA","DA","GA","THA","TA","PA"]);
    fusion = ismember(resp,["DA","THA"]);
    allValid(p) = sum(isMG & valid);
    allFusion(p) = sum(isMG & valid & fusion);
    for k = 1:8
        ix = isMG & valid & ids == videoIDs(k);
        validCounts(p,k) = sum(ix);
        if any(ix), participantRates(p,k) = 100*mean(fusion(ix)); end
    end
end
if any(sum(validCounts,1)==0)
    error('One or more video IDs have no valid trials. Inspect stimID labels.');
end
% Participant-equal mean per video, and participant-equal overall reference.
videoMean = NaN(1,8); videoSD = NaN(1,8);
for k = 1:8
    x = participantRates(:,k); x = x(isfinite(x));
    videoMean(k) = mean(x); videoSD(k) = std(x);
end
overallParticipant = 100*allFusion./allValid;
overallMean = mean(overallParticipant(isfinite(overallParticipant)));
trialCount = sum(validCounts,1);
participantCount = sum(isfinite(participantRates),1);
results = table((1:8)',videoIDs',videoMean',videoSD',trialCount',participantCount', ...
    'VariableNames',{'Video','StimID','MeanFusionPercent','ParticipantSD', ...
    'ValidTrials','ParticipantsWithData'});
disp('=== FIGURE B: VIDEO-SPECIFIC FUSION (PARTICIPANT-EQUAL MEANS) ===');
disp(results);
fprintf('Overall participant-equal fusion reference: %.2f%%\n',overallMean);
fprintf('Lowest video: %s (%.2f%%) | Highest video: %s (%.2f%%)\n', ...
    videoIDs(find(videoMean==min(videoMean),1)),min(videoMean), ...
    videoIDs(find(videoMean==max(videoMean),1)),max(videoMean));
fprintf('Range: %.2f percentage points (descriptive only).\n',max(videoMean)-min(videoMean));

f = figure('Color','w','Position',[100 100 1080 630]);
b = bar(1:8,videoMean,0.7,'FaceColor',[0.27 0.47 0.68], ...
    'EdgeColor','none'); hold on;
yline(overallMean,'--','Color',[0.18 0.18 0.18],'LineWidth',1.7, ...
    'Label',sprintf('Overall participant mean: %.2f%%',overallMean), ...
    'LabelHorizontalAlignment','right');
for k = 1:8
    text(k,videoMean(k)+2,sprintf('%.1f%%',videoMean(k)), ...
        'HorizontalAlignment','center','FontSize',11,'FontWeight','bold');
end
xticks(1:8); xticklabels("Video " + string(1:8));
xlabel('McGurk audiovisual stimulus (stimID 2.1–2.8)');
ylabel('McGurk fusion responses (%)');
title('Figure B. McGurk fusion by audiovisual stimulus','Color','k');
subtitle('20 participants | Three attention conditions pooled | DA/THA = fusion');
ylim([0 110]); xlim([0.4 8.6]); grid on; ax=gca; ax.YGrid='on'; ax.XGrid='off'; ax.GridAlpha=0.12;
set(ax,'FontSize',12,'Box','off');

scriptFolder=fileparts(mfilename('fullpath'));
if isempty(scriptFolder), scriptFolder=pwd; end
out=fullfile(scriptFolder,'Results');
if ~isfolder(out), mkdir(out); end
writetable(results,fullfile(out,'FigureB_video_fusion_summary.csv'));
writematrix(participantRates,fullfile(out,'FigureB_participant_video_rates.csv'));
exportgraphics(f,fullfile(out,'FigureB_Attention_ByVideo.png'),'Resolution',300);
savefig(f,fullfile(out,'FigureB_Attention_ByVideo.fig'));
fprintf('Saved Figure B PNG, FIG and CSV files to: %s\n',out);
