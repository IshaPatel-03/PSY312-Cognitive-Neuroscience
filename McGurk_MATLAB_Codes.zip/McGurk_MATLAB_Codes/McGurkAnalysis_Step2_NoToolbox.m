%% McGurk Attention Experiment - STEP 2 (NO TOOLBOX REQUIRED)
% Participant-level repeated-measures analysis of fusion percentages.
% Requires base MATLAB only. Do not edit original participant CSVs.
clear; clc; close all;

%% 1. Select Step 1 summary
[fileName, folderName] = uigetfile('*.csv', ...
    'Select participant_fusion_summary.csv');
if isequal(fileName,0)
    error('No file selected. Run again and select participant_fusion_summary.csv.');
end
if ~strcmpi(fileName,'participant_fusion_summary.csv')
    error('Select participant_fusion_summary.csv, not another CSV.');
end
T = readtable(fullfile(folderName,fileName),'TextType','string');
needed = {'participantID','attention','FusionPercent'};
assert(all(ismember(needed,T.Properties.VariableNames)), ...
    'Required columns are missing from the summary file.');
T.participantID = string(T.participantID);
T.attention = lower(strtrim(string(T.attention)));
assert(all(ismember(T.attention,["focused","search10","search15"])), ...
    'Unexpected attention condition found.');
assert(numel(unique(T.participantID)) == 20, ...
    'Expected 20 distinct participants.');
assert(height(T) == 60, 'Expected exactly 60 participant-condition rows.');

%% 2. Build participant-by-condition matrix
W = unstack(T(:,needed),'FusionPercent','attention');
W = W(:,{'participantID','focused','search10','search15'});
W = sortrows(W,'participantID');
X = W{:,2:4};
assert(isequal(size(X),[20 3]) && all(isfinite(X(:))), ...
    'Missing, duplicate, or non-finite participant percentages.');
assert(all(X(:)>=0 & X(:)<=100), 'Fusion percentages outside 0-100.');
conditions = ["Focused";"Search 10";"Search 15"];
fprintf('Loaded %d participants and %d conditions.\n',size(X,1),size(X,2));
disp('=== PARTICIPANT-LEVEL FUSION RATES (%) ==='); disp(W);

%% 3. Descriptive statistics and exact t-based confidence intervals
n = size(X,1);
mu = mean(X,1);
sd = std(X,0,1);
sem = sd/sqrt(n);
tcrit = t_quantile_base(0.975,n-1);
ciLo = mu-tcrit*sem;
ciHi = mu+tcrit*sem;
descriptives = table(conditions,repmat(n,3,1),mu',sd',sem',ciLo',ciHi', ...
    'VariableNames',{'Condition','N','MeanPercent','SD','SEM','CI95Lower','CI95Upper'});
disp('=== DESCRIPTIVE STATISTICS ==='); disp(descriptives);

%% 4. One-way repeated-measures ANOVA, including GG correction
mainStats = rm_anova_base(X);
disp('=== REPEATED-MEASURES ANOVA ==='); disp(mainStats);
fprintf('NOTE: GG-adjusted p-value is the conservative primary ANOVA p-value.\n');

%% 5. Paired t-tests with Holm correction
pairs = [1 2;1 3;2 3];
pairLabels = ["Focused vs Search 10";"Focused vs Search 15"; ...
              "Search 10 vs Search 15"];
diffMeans = zeros(3,1); tVals=zeros(3,1); pRaw=zeros(3,1);
ciDiffLo=zeros(3,1); ciDiffHi=zeros(3,1); dz=zeros(3,1);
for j=1:3
    d = X(:,pairs(j,1))-X(:,pairs(j,2));
    diffMeans(j) = mean(d);
    sdDiff = std(d);
    if sdDiff < 1e-12
        if abs(diffMeans(j)) < 1e-12
            tVals(j)=0; pRaw(j)=1; dz(j)=0;
        else
            tVals(j)=sign(diffMeans(j))*Inf; pRaw(j)=0;
            dz(j)=sign(diffMeans(j))*Inf;
        end
        ciDiffLo(j)=diffMeans(j); ciDiffHi(j)=diffMeans(j);
    else
        tVals(j)=diffMeans(j)/(sdDiff/sqrt(n));
        pRaw(j)=t_twosided_p_base(tVals(j),n-1);
        dz(j)=diffMeans(j)/sdDiff;
        margin=tcrit*sdDiff/sqrt(n);
        ciDiffLo(j)=diffMeans(j)-margin;
        ciDiffHi(j)=diffMeans(j)+margin;
    end
end
pHolm = holm_adjust_base(pRaw);
pairwise = table(pairLabels,diffMeans,tVals,repmat(n-1,3,1),pRaw,pHolm, ...
    ciDiffLo,ciDiffHi,dz, ...
    'VariableNames',{'Comparison','MeanDifferencePP','t','df','pUnadjusted', ...
    'pHolm','CI95LowerPP','CI95UpperPP','CohensDz'});
disp('=== PAIRED COMPARISONS (HOLM CORRECTION) ==='); disp(pairwise);

%% 6. Sensitivity analysis excluding YP
W19 = W(W.participantID~="YP",:);
assert(height(W19)==19,'Expected 19 participants after excluding YP.');
X19 = W19{:,2:4};
sensitivity = rm_anova_base(X19);
disp('=== SENSITIVITY: REPEATED-MEASURES ANOVA EXCLUDING YP ===');
disp(sensitivity);

%% 7. Figure C: participant trajectories and mean 95% CIs
f=figure('Color','w','Position',[100 100 920 580]);
ax=axes(f); hold(ax,'on');
for i=1:n
    plot(ax,1:3,X(i,:),'-o','Color',[0.76 0.76 0.76], ...
        'MarkerFaceColor',[0.83 0.83 0.83],'MarkerEdgeColor',[0.76 0.76 0.76], ...
        'MarkerSize',4,'LineWidth',0.7);
end
errorbar(ax,1:3,mu,mu-ciLo,ciHi-mu,'k','LineStyle','-', ...
    'Marker','o','MarkerSize',9,'MarkerFaceColor','k', ...
    'LineWidth',2.2,'CapSize',12);
xlim(ax,[0.7 3.3]); ylim(ax,[0 105]);
xticks(ax,1:3); xticklabels(ax,cellstr(conditions));
ylabel(ax,'McGurk fusion responses (%)');
title(ax,'Figure C. Fusion rates across attention conditions');
subtitle(ax,'Grey: individual participants | Black: mean and 95% t CI');
grid(ax,'on'); ax.Box='off'; ax.FontSize=12;
exportgraphics(f,fullfile(folderName,'Figure_C_FusionRates.png'),'Resolution',300);
savefig(f,fullfile(folderName,'Figure_C_FusionRates.fig'));

%% 8. Save tables in the same Results folder as selected CSV
writetable(W,fullfile(folderName,'fusion_wide.csv'));
writetable(descriptives,fullfile(folderName,'fusion_descriptives.csv'));
writetable(mainStats,fullfile(folderName,'anova_results_no_toolbox.csv'));
writetable(pairwise,fullfile(folderName,'pairwise_comparisons_holm.csv'));
writetable(sensitivity,fullfile(folderName,'anova_excluding_YP.csv'));
fprintf('\nSTEP 2 COMPLETE! Results saved to:\n%s\n',folderName);
fprintf('Interpret the statistical results only after checking data quality and attention-task performance.\n');

%% Local functions: base MATLAB only
function result=rm_anova_base(A)
    [n,k]=size(A);
    grand=mean(A(:));
    subjMeans=mean(A,2);
    condMeans=mean(A,1);
    ssCond=n*sum((condMeans-grand).^2);
    ssSubj=k*sum((subjMeans-grand).^2);
    ssTotal=sum((A(:)-grand).^2);
    ssError=ssTotal-ssCond-ssSubj;
    if ssError < 0 && abs(ssError)<1e-8
        ssError=0;
    end
    dfCond=k-1; dfError=(n-1)*(k-1);
    msCond=ssCond/dfCond; msError=ssError/dfError;
    F=msCond/msError;
    pUncorrected=f_upper_p_base(F,dfCond,dfError);
    partialEtaSquared=ssCond/(ssCond+ssError);

    % Greenhouse-Geisser epsilon via covariance contrast projection
    S=cov(A);
    P=eye(k)-ones(k)/k;
    V=P*S*P;
    epsilonGG=(trace(V)^2)/((k-1)*trace(V*V));
    epsilonGG=max(1/(k-1),min(1,epsilonGG));
    df1GG=epsilonGG*dfCond;
    df2GG=epsilonGG*dfError;
    pGG=f_upper_p_base(F,df1GG,df2GG);
    result=table(n,F,dfCond,dfError,pUncorrected,epsilonGG, ...
        df1GG,df2GG,pGG,partialEtaSquared, ...
        'VariableNames',{'N','F','df1','df2','pUncorrected', ...
        'GreenhouseGeisserEpsilon','df1GG','df2GG','pGG','PartialEtaSquared'});
end
function p=f_upper_p_base(F,d1,d2)
    if F<=0
        p=1; return;
    end
    if isinf(F)
        p=0; return;
    end
    % F survival function using regularized incomplete beta
    z=d2/(d2+d1*F);
    p=betainc(z,d2/2,d1/2);
end
function p=t_twosided_p_base(t,df)
    if isinf(t)
        p=0; return;
    end
    z=df/(df+t*t);
    p=betainc(z,df/2,0.5);
end
function t=t_quantile_base(prob,df)
    % For prob>0.5: P(T<=t)=prob, T~Student-t(df)
    assert(prob>0.5 && prob<1 && df>0);
    z=betaincinv(2*(1-prob),df/2,0.5);
    t=sqrt(df*(1-z)/z);
end
function adjusted=holm_adjust_base(p)
    m=numel(p);
    [sorted,order]=sort(p);
    vals=zeros(m,1);
    running=0;
    for j=1:m
        running=max(running,(m-j+1)*sorted(j));
        vals(j)=min(1,running);
    end
    adjusted=zeros(m,1);
    adjusted(order)=vals;
end
