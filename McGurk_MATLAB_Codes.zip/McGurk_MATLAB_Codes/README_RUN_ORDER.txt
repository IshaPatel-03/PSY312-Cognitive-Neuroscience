MCGURK PROJECT — REPRODUCIBILITY PACKAGE

CONTENTS
- AI_Use_Log.docx: disclosure and analysis decisions.
- FigureAWithWaves.m: anchor-paper reproduction, provisional ID matching.
- FigureB_Analysis.m: anchor-paper eight-video stimulus audit (original Figure B).
- FigureB_Attention_ByVideo_NoToolbox.m: separate eight-video analysis of the new 20-participant experiment. Do not confuse with anchor Figure B.
- McGurkAnalysis_Step1.m: raw-trial import, cleaning, scoring, participant summaries.
- McGurkAnalysis_Step2_NoToolbox.m: repeated-measures ANOVA, Greenhouse-Geisser correction, Holm pairwise tests, Figure C.
- McGurkAnalysis_Steps3_4_NoToolbox.m: search accuracy, congruent speech, Figures D/E and diagnostics.
- Anchor_Lee_Original_CSVs.zip: original anchor experiment CSVs (extract before running Figure A/B).
- Final_Experiment_20_CSVs.zip: original 20 experiment CSVs (extract before running extension analyses).
- GOLD_MSI_OSF.xlsx: questionnaire source used for Figure A.
- participant_fusion_summary.csv: previously generated intermediate summary for independent comparison.

RUN ORDER
1. Extract Anchor_Lee_Original_CSVs.zip to a folder. Put GOLD_MSI_OSF.xlsx alongside FigureAWithWaves.m (already included in this package). Run FigureAWithWaves.m and select extracted anchor folder when prompted.
2. Run FigureB_Analysis.m and select the same anchor folder. Figure B concerns the original anchor data, NOT the 20-person experiment.
3. Extract Final_Experiment_20_CSVs.zip to a DIFFERENT folder. Run McGurkAnalysis_Step1.m and select the extracted folder. The script creates Results/participant_fusion_summary.csv.
4. Run McGurkAnalysis_Step2_NoToolbox.m and select Results/participant_fusion_summary.csv. It exports ANOVA tables and Figure C.
5. Run McGurkAnalysis_Steps3_4_NoToolbox.m and select the final-experiment folder. It exports Figures D/E and control tables.
6. Optional: Run FigureB_Attention_ByVideo_NoToolbox.m on the final-experiment folder for exploratory new-experiment stimulus effects.

REPRODUCIBILITY NOTES
- These are copies of the full final scripts available in the project files, not abbreviated code fragments.
- MATLAB is required. The scripts were authored for base MATLAB without Statistics and Machine Learning Toolbox, but execution was NOT re-run in MATLAB in this package-creation environment. The instructor should confirm results by running them.
- Figure A is explicitly provisional: participant matching between questionnaire and behavior is not independently verified, and two out-of-range questionnaire responses were flagged. Do not present its association results as fully validated.
- For original datasets, do not mix the anchor and new experiment folders.
- The MATLAB scripts have interactive folder/file prompts. For a faithful reproduction, keep original filenames and directory contents and follow the prompts.
- The original 20-person data archive uses filenames containing "_McGurk_Attention centre"; this matches the script wildcard "*_McGurk_Attention*.csv".
- The attached AI log is a reconstructed, honest summary of AI involvement based on project artifacts and discussions, not a timestamped transcript of every prompt.
