%% McGurk Attention Experiment - STEP 1
% Import, clean, check, and summarise data from 20 PsychoPy CSV files.
% No statistical significance tests are performed in this step.

clear; clc; close all;

%% 1. Select the folder containing ORIGINAL participant CSV files
% IMPORTANT: Select the extracted folder, not the ZIP file.
dataFolder = uigetdir(pwd, 'Select the folder with the 20 original participant CSV files');
if isequal(dataFolder, 0)
    error('No folder was selected.');
end

% Only include original participant files, not generated analysis CSVs.
files = dir(fullfile(dataFolder, '*_McGurk_Attention*.csv'));
fprintf('Found %d participant CSV files.\n', numel(files));
if numel(files) ~= 20
    error('Expected 20 original participant CSV files; found %d. Check the selected folder.', numel(files));
end

%% 2. Set up the Results folder beside this MATLAB script
scriptFolder = fileparts(mfilename('fullpath'));
if isempty(scriptFolder)
    scriptFolder = pwd;
end
resultsFolder = fullfile(scriptFolder, 'Results');
if ~isfolder(resultsFolder)
    mkdir(resultsFolder);
end

%% 3. Import all participant files
allData = table();
requiredVars = ["attention", "stimType", "stimID", ...
                "expectedPercept", "textbox.text"];

for i = 1:numel(files)
    filename = fullfile(files(i).folder, files(i).name);
    opts = detectImportOptions(filename, 'VariableNamingRule', 'preserve');

    % Force key columns to text, retaining IDs and blank responses.
    for k = 1:numel(requiredVars)
        varName = char(requiredVars(k));
        if ~ismember(requiredVars(k), string(opts.VariableNames))
            error('Missing column "%s" in %s', varName, files(i).name);
        end
        opts = setvartype(opts, varName, 'string');
    end

    T = readtable(filename, opts);
    T.attention = strtrim(string(T.attention));
    T = T(~ismissing(T.attention) & strlength(T.attention) > 0, :);

    % Participant ID is the text before "_McGurk" in the filename.
    pid = extractBefore(string(files(i).name), '_McGurk');
    T.participantID = repmat(pid, height(T), 1);

    % Keep the same columns, in the same order, for every file.
    T = T(:, {'participantID', 'attention', 'stimType', ...
              'stimID', 'expectedPercept', 'textbox.text'});
    allData = [allData; T];
end

fprintf('Imported %d experimental trials from %d participants.\n', ...
    height(allData), numel(unique(allData.participantID)));

%% 4. Clean and code speech responses
resp = string(allData.('textbox.text'));
resp(ismissing(resp)) = "";
allData.response = upper(regexprep(strtrim(resp), '\s+', ''));

allData.attention = lower(strtrim(string(allData.attention)));
allData.stimType = strtrim(string(allData.stimType));
allData.expectedPercept = strtrim(string(allData.expectedPercept));

% The main outcome is fusion on McGurk trials.
allData.isMcGurk = strcmpi(allData.stimType, 'McGurk');

% Responses present in the original dataset.
knownResponses = ["BA", "DA", "GA", "THA", "TA", "PA"];
allData.validResponse = ismember(allData.response, knownResponses);

% DA and THA are coded as fusion for these McGurk stimuli.
allData.isFusion = allData.isMcGurk & ...
    ismember(allData.response, ["DA", "THA"]);

% Flag unexpected nonblank responses for manual review.
unexpected = allData(strlength(allData.response) > 0 & ...
    ~allData.validResponse, :);
if height(unexpected) > 0
    warning('%d unexpected responses were found. Review the saved file.', ...
        height(unexpected));
end

%% 5. Trial counts by participant and attention condition
participantCounts = groupsummary(allData, ...
    {'participantID', 'attention'});

disp('=== TRIAL COUNTS BY PARTICIPANT AND CONDITION ===');
disp(participantCounts);

%% 6. Trial counts by participant, condition and stimulus type
trialCheck = groupsummary(allData, ...
    {'participantID', 'attention', 'stimType'});

disp('=== TRIAL COUNTS BY STIMULUS TYPE ===');
disp(trialCheck);

%% 7. Missing speech responses
missingResponses = allData(strlength(allData.response) == 0, :);
fprintf('\nMissing speech responses: %d\n', height(missingResponses));
disp(missingResponses(:, ...
    {'participantID', 'attention', 'stimType', 'stimID', 'response'}));

%% 8. McGurk response-category counts
mcAll = allData(allData.isMcGurk, :);
responseCounts = groupsummary(mcAll, {'response', 'attention'});

disp('=== McGURK RESPONSE CATEGORIES ===');
disp(responseCounts);

%% 9. Calculate fusion percentages per participant and condition
% Missing or unexpected responses are not counted in the denominator.
mcValid = allData(allData.isMcGurk & allData.validResponse, :);
summary = groupsummary(mcValid, ...
    {'participantID', 'attention'}, 'mean', 'isFusion');
summary.FusionCount = round(summary.mean_isFusion .* summary.GroupCount);
summary.FusionPercent = 100 .* summary.mean_isFusion;

disp('=== PARTICIPANT FUSION PERCENTAGES ===');
disp(summary(:, {'participantID', 'attention', 'GroupCount', ...
                 'FusionCount', 'FusionPercent'}));

%% 10. Examine YP's condition imbalance without changing the raw data
ypData = allData(allData.participantID == "YP", :);
ypBreakdown = groupsummary(ypData, {'attention', 'stimType'});

disp('=== YP TRIAL BREAKDOWN ===');
disp(ypBreakdown);

%% 11. Check expected-percept labels
expectedCounts = groupsummary(mcAll, 'expectedPercept');
disp('=== McGURK EXPECTED PERCEPT LABELS ===');
disp(expectedCounts);

%% 12. Save results (never overwrite original participant CSVs)
writetable(allData, fullfile(resultsFolder, 'cleaned_trials.csv'));
writetable(participantCounts, fullfile(resultsFolder, 'trial_counts.csv'));
writetable(trialCheck, fullfile(resultsFolder, 'trial_type_counts.csv'));
writetable(missingResponses, fullfile(resultsFolder, 'missing_responses.csv'));
writetable(responseCounts, fullfile(resultsFolder, 'mcgurk_response_counts.csv'));
writetable(summary, fullfile(resultsFolder, 'participant_fusion_summary.csv'));
writetable(ypBreakdown, fullfile(resultsFolder, 'yp_trial_breakdown.csv'));
writetable(unexpected, fullfile(resultsFolder, 'unexpected_responses.csv'));

fprintf('\nSTEP 1 COMPLETE!\n');
fprintf('Results saved in:\n%s\n', resultsFolder);
