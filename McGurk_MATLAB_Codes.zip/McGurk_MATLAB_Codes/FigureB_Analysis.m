
%% FIGURE B: MCGURK FUSION RATE BY STIMULUS
% Theme 8 - Project 29
% Research question:
% Do all eight McGurk stimuli produce the same fusion rate?
%
% Response coding:
% 1 = Ba
% 2 = Ga
% 3 = Da/Tha (fusion)
%
% McGurk category_num = 1 to 8
%
% No Statistics and Machine Learning Toolbox required.

clear;
clc;
close all;

%% STEP 1: SELECT PARTICIPANT DATA FOLDER

folder = uigetdir(pwd, ...
    'Select the folder containing participant CSV files');

if isequal(folder,0)
    error('No folder selected.');
end

files = dir(fullfile(folder,'*.csv'));

allData = table();
fileCount = 0;

%% STEP 2: LOAD PARTICIPANT CSV FILES

for i = 1:numel(files)

    filename = files(i).name;

    % Skip previously generated analysis files
    if startsWith(filename,'Figure') || ...
       startsWith(filename,'GoldMSI') || ...
       startsWith(filename,'Provisional') || ...
       startsWith(filename,'Participant_')
        continue;
    end

    filePath = fullfile(folder,filename);

    T = readtable(filePath, ...
        'VariableNamingRule','preserve');

    % Participant CSVs have exactly 6 columns
    if width(T) ~= 6
        continue;
    end

    T.Properties.VariableNames = ...
        {'subject','starttime','videoname', ...
         'category_num','response','RT'};

    % Ensure required columns are numeric
    if ~isnumeric(T.subject) || ...
       ~isnumeric(T.category_num) || ...
       ~isnumeric(T.response)
        continue;
    end

    allData = [allData; T];
    fileCount = fileCount + 1;

end

if isempty(allData)
    error('No valid participant CSV files found.');
end

fprintf('\n=== EXPERIMENT DATA ===\n');
fprintf('Files loaded: %d\n',fileCount);
fprintf('Total trials: %d\n',height(allData));
fprintf('Participants: %d\n', ...
    numel(unique(allData.subject)));

%% STEP 3: EXTRACT MCGURK TRIALS

isMG = allData.category_num >= 1 & ...
       allData.category_num <= 8;

MG = allData(isMG,:);

% A Da/Tha response indicates fusion
MG.fusion = double(MG.response == 3);

fprintf('McGurk trials: %d\n',height(MG));

%% STEP 4: CALCULATE FUSION FOR EACH VIDEO

videoNumber = (1:8)';

fusionPercent = NaN(8,1);
trialCount = zeros(8,1);
fusionCount = zeros(8,1);
participantCount = zeros(8,1);

for k = 1:8

    idx = MG.category_num == k;

    trialCount(k) = sum(idx);

    fusionCount(k) = sum(MG.fusion(idx));

    participantCount(k) = ...
        numel(unique(MG.subject(idx)));

    if trialCount(k) > 0

        fusionPercent(k) = ...
            100 * fusionCount(k) / trialCount(k);

    end

end

%% STEP 5: CALCULATE OVERALL FUSION

% Overall trial-weighted percentage
overallFusion = 100 * mean(MG.fusion);

% Participant-level average for comparison
subjects = unique(MG.subject);
subjectFusion = NaN(numel(subjects),1);

for i = 1:numel(subjects)

    idx = MG.subject == subjects(i);

    subjectFusion(i) = ...
        100 * mean(MG.fusion(idx));

end

meanParticipantFusion = mean(subjectFusion);

fprintf('\n=== FIGURE B RESULTS ===\n');

fprintf('Overall trial-weighted fusion: %.2f%%\n', ...
    overallFusion);

fprintf('Mean participant fusion: %.2f%%\n', ...
    meanParticipantFusion);

fprintf('\nFusion rate for each McGurk stimulus:\n');

for k = 1:8

    fprintf(['Video %d: %.2f%% fusion ' ...
             '(%d/%d trials, %d participants)\n'], ...
        k, ...
        fusionPercent(k), ...
        fusionCount(k), ...
        trialCount(k), ...
        participantCount(k));

end

%% STEP 6: IDENTIFY HIGHEST AND LOWEST

[highestRate,highestVideo] = max(fusionPercent);
[lowestRate,lowestVideo] = min(fusionPercent);

difference = highestRate - lowestRate;

fprintf('\n=== STIMULUS COMPARISON ===\n');

fprintf('Highest fusion: Video %d (%.2f%%)\n', ...
    highestVideo,highestRate);

fprintf('Lowest fusion: Video %d (%.2f%%)\n', ...
    lowestVideo,lowestRate);

fprintf('Difference: %.2f percentage points\n', ...
    difference);

%% STEP 7: CREATE BAR GRAPH

fig = figure( ...
    'Color','w', ...
    'Position',[150 150 1050 650], ...
    'Visible','on');

ax = axes('Parent',fig);

hold(ax,'on');

% Blue bars
b = bar(ax,videoNumber,fusionPercent,0.65);

b.FaceColor = [0.20 0.68 0.90];
b.EdgeColor = 'none';

% Dashed line showing overall fusion rate
yline(ax,overallFusion,'--', ...
    sprintf('Overall mean = %.2f%%',overallFusion), ...
    'Color',[0.25 0.25 0.25], ...
    'LineWidth',1.5, ...
    'LabelHorizontalAlignment','left', ...
    'LabelVerticalAlignment','bottom');

% Percentage labels above bars
for k = 1:8

    text(ax,k,fusionPercent(k)+2, ...
        sprintf('%.1f%%',fusionPercent(k)), ...
        'HorizontalAlignment','center', ...
        'FontSize',11, ...
        'FontWeight','bold', ...
        'Color','k');

end

% Axis formatting
xlim(ax,[0.4 8.6]);
ylim(ax,[0 110]);

xticks(ax,1:8);

xticklabels(ax,{ ...
    'Video 1','Video 2','Video 3','Video 4', ...
    'Video 5','Video 6','Video 7','Video 8'});

xlabel(ax,'McGurk stimulus', ...
    'FontSize',13, ...
    'FontWeight','bold');

ylabel(ax,'Fusion responses (%)', ...
    'FontSize',13, ...
    'FontWeight','bold');

title(ax, ...
    'Figure B - McGurk Fusion Rate Across Eight Stimuli', ...
    'FontSize',15, ...
    'FontWeight','bold');

set(ax, ...
    'Color','w', ...
    'XColor','k', ...
    'YColor','k', ...
    'FontSize',11, ...
    'LineWidth',1.1, ...
    'Box','off', ...
    'TickDir','out');

grid(ax,'on');
ax.XGrid = 'off';
ax.YGrid = 'on';
ax.GridAlpha = 0.12;

%% STEP 8: SAVE RESULTS

% Save output files in the script folder
outputFolder = fileparts(mfilename('fullpath'));

if isempty(outputFolder)
    outputFolder = pwd;
end

results = table( ...
    videoNumber, ...
    trialCount, ...
    fusionCount, ...
    participantCount, ...
    fusionPercent, ...
    'VariableNames',{ ...
    'Video', ...
    'TotalTrials', ...
    'FusionResponses', ...
    'Participants', ...
    'FusionPercent'});

writetable(results, ...
    fullfile(outputFolder,'Figure_B_Results.csv'));

exportgraphics(fig, ...
    fullfile(outputFolder,'Figure_B_Stimulus_Fusion.png'), ...
    'Resolution',300, ...
    'BackgroundColor','white');

savefig(fig, ...
    fullfile(outputFolder,'Figure_B_Stimulus_Fusion.fig'));

%% STEP 9: DISPLAY SUMMARY

fprintf('\n=== FILES SAVED ===\n');
fprintf('Figure_B_Stimulus_Fusion.png\n');
fprintf('Figure_B_Stimulus_Fusion.fig\n');
fprintf('Figure_B_Results.csv\n');

fprintf('\n=== INTERPRETATION ===\n');

fprintf(['The fusion rates across the eight McGurk ' ...
         'stimuli ranged from %.2f%% to %.2f%%.\n'], ...
         lowestRate,highestRate);

fprintf(['The difference between the highest and ' ...
         'lowest stimulus was %.2f percentage points.\n'], ...
         difference);

fprintf(['This describes variability across the ' ...
         'eight audiovisual stimuli.\n']);

% Keep figure visible
figure(fig);
shg;
