%% McGurk experiment - STEPS 3 AND 4 (base MATLAB only)
% Step 3: search-task performance and congruent speech accuracy.
% Step 4: publication-style descriptive figures and export tables.
% Select the folder of ORIGINAL participant CSVs, not cleaned_trials.csv.
% No Statistics and Machine Learning Toolbox required.
clear; clc; close all;

rawFolder = uigetdir(pwd, 'Select folder containing 20 ORIGINAL participant CSVs');
if isequal(rawFolder,0), error('No folder selected.'); end
files = dir(fullfile(rawFolder,'*_McGurk_Attention*.csv'));
if numel(files) ~= 20
    error('Expected 20 original participant CSVs, found %d. Select the extracted participant folder.',numel(files));
end

% Save alongside this script, regardless of MATLAB Current Folder.
scriptFolder = fileparts(mfilename('fullpath'));
if isempty(scriptFolder), scriptFolder = pwd; end
resultsFolder = fullfile(scriptFolder,'Results');
if ~isfolder(resultsFolder), mkdir(resultsFolder); end
fprintf('Importing %d original participant files...\n',numel(files));

% Import only the fields needed here; preserve original response and click logs.
D = table();
fields = {'attention','stimType','stimID','expectedPercept','textbox.text', ...
          'searchMouse.clicked_name','searchMouse.time'};
for k = 1:numel(files)
    path = fullfile(files(k).folder,files(k).name);
    opts = detectImportOptions(path,'VariableNamingRule','preserve');
    for j = 1:numel(fields)
        if ~ismember(fields{j},opts.VariableNames)
            error('Column "%s" missing in %s. Inspect original CSV headers.',fields{j},files(k).name);
        end
        opts = setvartype(opts,fields{j},'string');
    end
    T = readtable(path,opts);
    attention = lower(strtrim(string(T.attention)));
    keep = ismember(attention,["focused","search10","search15"]);
    pid = extractBefore(string(files(k).name),'_McGurk');
    n = sum(keep);
    speechCol = string(T.('textbox.text'));
    clickCol = string(T.('searchMouse.clicked_name'));
    timeCol = string(T.('searchMouse.time'));
    Q = table(repmat(pid,n,1), attention(keep), ...
        string(T.stimType(keep)),string(T.stimID(keep)), ...
        string(T.expectedPercept(keep)),speechCol(keep), ...
        clickCol(keep),timeCol(keep), ...
        'VariableNames',{'participantID','attention','stimType','stimID', ...
        'expectedPercept','rawResponse','clickNames','clickTimes'});
    D = [D;Q]; %#ok<AGROW>
end
fprintf('Imported %d trials across %d participants.\n',height(D),numel(unique(D.participantID)));

%% STEP 3A: classify responses and search clicks
D.response = upper(regexprep(strtrim(D.rawResponse),'\s+',''));
D.response(ismissing(D.response)) = "";
D.stimType = upper(strtrim(D.stimType));
D.expectedPercept = upper(strtrim(D.expectedPercept));
D.isMcGurk = D.stimType == "MCGURK";
D.isCongruent = ismember(D.stimType,["BA","DA","GA"]);
D.isSearch = ismember(D.attention,["search10","search15"]);
D.validSpeech = ismember(D.response,["BA","DA","GA","THA","TA","PA"]);
D.isFusion = D.isMcGurk & ismember(D.response,["DA","THA"]);
D.speechCorrect = D.isCongruent & D.response == D.expectedPercept;

% PsychoPy searchMouse.clicked_name is a stringified list, e.g.
% "['target']", "[None]", or "['target', None]".
% We score a hit if any click was recorded on the named target.
D.targetClicked = false(height(D),1);
D.searchRT = nan(height(D),1);
D.clickRecorded = false(height(D),1);
for i = 1:height(D)
    % Missing PsychoPy click logs must not be converted with char(<missing>).
    % Preserve the missing value in D.clickNames / D.clickTimes for auditing.
    nameValue = string(D.clickNames(i));
    timeValue = string(D.clickTimes(i));
    if ismissing(nameValue), nameValue = ""; end
    if ismissing(timeValue), timeValue = ""; end
    names = char(nameValue);
    times = char(timeValue);

    D.targetClicked(i) = contains(lower(nameValue), 'target');
    % Non-empty list, excluding None, means a named click was logged.
    D.clickRecorded(i) = ~isempty(regexp(names,'\[.*\]','once')) && ...
        ~strcmp(strtrim(names),'[]') && ...
        ~strcmpi(strtrim(names),'[None]');

    % Extract numeric timestamps from the PsychoPy list string.
    ts = regexp(times,'[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?','match');
    if ~isempty(ts)
        vals = str2double(ts);
        vals = vals(isfinite(vals) & vals >= 0);
        if ~isempty(vals), D.searchRT(i) = vals(1); end
    end
end
% Timing is exploratory: first logged click time, not guaranteed target-hit RT.
% Search accuracy here means clicked target / search trials.

ids = unique(D.participantID,'stable');
conds = ["focused","search10","search15"];
searchConds = ["search10","search15"];

%% STEP 3B: per-participant search accuracy and first-click latency
searchRows = table();
for i = 1:numel(ids)
    for j = 1:numel(searchConds)
        ix = D.participantID == ids(i) & D.attention == searchConds(j);
        n = sum(ix);
        hits = sum(D.targetClicked(ix));
        rt = D.searchRT(ix & D.targetClicked); % only target-hit trials
        rt = rt(isfinite(rt));
        if n == 0, pct = NaN; else, pct = 100*hits/n; end
        if isempty(rt), meanRT = NaN; else, meanRT = mean(rt); end
        row = table(ids(i),searchConds(j),n,hits,pct,numel(rt),meanRT, ...
            'VariableNames',{'participantID','attention','SearchTrials', ...
            'TargetHitTrials','TargetHitPercent','NHitFirstClickTimes','MeanHitFirstClickTimeSec'});
        searchRows = [searchRows;row]; %#ok<AGROW>
    end
end

%% STEP 3C: congruent speech accuracy (BA, DA, GA)
congruentRows = table();
for i = 1:numel(ids)
    for j = 1:numel(conds)
        ix = D.participantID == ids(i) & D.attention == conds(j) & D.isCongruent;
        n = sum(ix); valid = sum(D.validSpeech(ix));
        correct = sum(D.speechCorrect(ix));
        if valid > 0, pct = 100*correct/valid; else, pct = NaN; end
        row = table(ids(i),conds(j),n,valid,correct,pct, ...
            'VariableNames',{'participantID','attention','CongruentTrials', ...
            'ValidSpeechResponses','CorrectSpeechResponses','CongruentAccuracyPercent'});
        congruentRows = [congruentRows;row]; %#ok<AGROW>
    end
end

%% STEP 3D: participant-level summary and diagnostics
fprintf('\n=== SEARCH TARGET-HIT RATES ===\n');
searchStats = table();
for j = 1:2
    x = searchRows.TargetHitPercent(searchRows.attention == searchConds(j));
    searchStats = [searchStats; table(searchConds(j),mean(x,'omitnan'),std(x,'omitnan'), ...
        'VariableNames',{'Condition','MeanHitPercent','SD'})]; %#ok<AGROW>
end
disp(searchStats);
fprintf('\n=== CONGRUENT SPEECH ACCURACY ===\n');
congruentStats = table();
for j = 1:3
    x = congruentRows.CongruentAccuracyPercent(congruentRows.attention == conds(j));
    congruentStats = [congruentStats; table(conds(j),mean(x,'omitnan'),std(x,'omitnan'), ...
        'VariableNames',{'Condition','MeanAccuracyPercent','SD'})]; %#ok<AGROW>
end
disp(congruentStats);

fprintf('\n=== DATA QUALITY ===\n');
fprintf('Total trials: %d | McGurk: %d | Congruent: %d\n',height(D),sum(D.isMcGurk),sum(D.isCongruent));
fprintf('Blank speech responses: %d\n',sum(D.response == ""));
fprintf('Search trials without a recorded target click: %d\n',sum(D.isSearch & ~D.targetClicked));
fprintf('Search trials without a parseable click time: %d\n',sum(D.isSearch & isnan(D.searchRT)));

%% STEP 4: figures - base MATLAB, descriptive only
% 95% t critical for df=19; numerical integration via betainc (base MATLAB).
% Plot individual participant trajectories and group means +/- 95% CI.
% CIs describe uncertainty in condition means; paired comparisons require
% within-participant tests from Step 2.
plotConditions = @(ax,vals,xlabels,ytitle,ttl) plotRepeated(ax,vals,xlabels,ytitle,ttl);

% Figure D: target-hit accuracy
S = nan(numel(ids),2);
for i = 1:numel(ids)
    for j = 1:2
        ix = searchRows.participantID == ids(i) & searchRows.attention == searchConds(j);
        if any(ix), S(i,j) = searchRows.TargetHitPercent(find(ix,1)); end
    end
end
f1 = figure('Color','w','Position',[100 100 900 600]);
plotConditions(gca,S,{'Search 10','Search 15'},'Target-hit trials (%)', ...
    'Figure D. Visual-search target-hit performance');
exportgraphics(f1,fullfile(resultsFolder,'Figure_D_SearchAccuracy.png'),'Resolution',300);
savefig(f1,fullfile(resultsFolder,'Figure_D_SearchAccuracy.fig'));

% Figure E: congruent speech accuracy
C = nan(numel(ids),3);
for i = 1:numel(ids)
    for j = 1:3
        ix = congruentRows.participantID == ids(i) & congruentRows.attention == conds(j);
        if any(ix), C(i,j) = congruentRows.CongruentAccuracyPercent(find(ix,1)); end
    end
end
f2 = figure('Color','w','Position',[140 140 950 600]);
plotConditions(gca,C,{'Focused','Search 10','Search 15'}, ...
    'Congruent speech accuracy (%)','Figure E. Congruent speech accuracy');
exportgraphics(f2,fullfile(resultsFolder,'Figure_E_CongruentAccuracy.png'),'Resolution',300);
savefig(f2,fullfile(resultsFolder,'Figure_E_CongruentAccuracy.fig'));

% Figure F: McGurk fusion percentages re-derived from ORIGINAL files.
F = nan(numel(ids),3);
fusionRows = table();
for i = 1:numel(ids)
    for j = 1:3
        ix = D.participantID == ids(i) & D.attention == conds(j) & D.isMcGurk;
        n = sum(ix); v = sum(D.validSpeech(ix)); hits = sum(D.isFusion(ix));
        if v > 0, pct = 100*hits/v; else, pct = NaN; end
        F(i,j) = pct;
        fusionRows = [fusionRows; table(ids(i),conds(j),n,v,hits,pct, ...
            'VariableNames',{'participantID','attention','McGurkTrials', ...
            'ValidSpeechResponses','FusionResponses','FusionPercent'})]; %#ok<AGROW>
    end
end
f3 = figure('Color','w','Position',[180 180 950 600]);
plotConditions(gca,F,{'Focused','Search 10','Search 15'}, ...
    'McGurk fusion responses (%)','Figure C. McGurk fusion across attention conditions');
exportgraphics(f3,fullfile(resultsFolder,'Figure_C_Fusion_Validated.png'),'Resolution',300);
savefig(f3,fullfile(resultsFolder,'Figure_C_Fusion_Validated.fig'));

%% Save all analysis tables
writetable(D,fullfile(resultsFolder,'step34_trial_diagnostics.csv'));
writetable(searchRows,fullfile(resultsFolder,'search_participant_summary.csv'));
writetable(searchStats,fullfile(resultsFolder,'search_condition_summary.csv'));
writetable(congruentRows,fullfile(resultsFolder,'congruent_participant_summary.csv'));
writetable(congruentStats,fullfile(resultsFolder,'congruent_condition_summary.csv'));
writetable(fusionRows,fullfile(resultsFolder,'fusion_recomputed_from_raw.csv'));

% Compare new fusion estimates against existing Step 2 participant summary.
previous = fullfile(resultsFolder,'participant_fusion_summary.csv');
if isfile(previous)
    P = readtable(previous,'TextType','string');
    if all(ismember({'participantID','attention','FusionPercent'},P.Properties.VariableNames))
        P.participantID = string(P.participantID);
        P.attention = lower(string(P.attention));
        mismatches = 0;
        for z = 1:height(fusionRows)
            ix = P.participantID == fusionRows.participantID(z) & ...
                 P.attention == fusionRows.attention(z);
            if sum(ix) ~= 1 || abs(P.FusionPercent(find(ix,1)) - fusionRows.FusionPercent(z)) > .02
                mismatches = mismatches + 1;
            end
        end
        fprintf('Fusion comparison with Step 2: %d mismatched participant-condition rows.\n',mismatches);
    end
end
fprintf('\nSTEPS 3 AND 4 COMPLETE! Outputs saved to:\n%s\n',resultsFolder);
fprintf('CAUTION: A target click is a recorded target hit, not proof of sustained attention.\n');
fprintf('First-click time is exploratory and may not equal target-selection RT.\n');

%% Local plotting function (must remain at end of script)
function plotRepeated(ax,X,labels,yLabel,plotTitle)
    hold(ax,'on');
    [n,k] = size(X);
    for i = 1:n
        plot(ax,1:k,X(i,:),'-o','Color',[.78 .78 .78], ...
            'MarkerFaceColor',[.82 .82 .82],'MarkerEdgeColor',[.78 .78 .78], ...
            'MarkerSize',3,'LineWidth',.8);
    end
    m = nan(1,k); ci = nan(1,k);
    for j = 1:k
        x = X(isfinite(X(:,j)),j);
        nj = numel(x);
        if nj > 0, m(j) = mean(x); end
        if nj > 1
            % Invert Student-t CDF using betainc and fzero, no toolbox.
            df = nj-1;
            tcdf0 = @(t) 1 - .5*betainc(df/(df+t.^2),df/2,.5);
            crit = fzero(@(t) tcdf0(t)-.975,[0,20]);
            ci(j) = crit*std(x)/sqrt(nj);
        end
    end
    errorbar(ax,1:k,m,ci,'-ko','LineWidth',2.4, ...
        'MarkerFaceColor','k','MarkerSize',8,'CapSize',12);
    xlim(ax,[.65 k+.35]); ylim(ax,[0 100]);
    xticks(ax,1:k); xticklabels(ax,labels);
    ylabel(ax,yLabel); title(ax,plotTitle,'FontWeight','bold');
    grid(ax,'on'); ax.GridAlpha = .12;
    set(ax,'FontSize',12,'Box','off');
    hold(ax,'off');
end
